package com.example.nftmarketplace.dtos

class LoginDTO {
    val email = ""
    val password = ""
}