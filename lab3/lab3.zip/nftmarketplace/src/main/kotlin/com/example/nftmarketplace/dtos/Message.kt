package com.example.nftmarketplace.dtos

class Message(public val message: String) {
}