package com.example.nftmarketplace.dtos

class RegisterDTO {
    val name = ""
    val email = ""
    val password = ""
}