package com.example.nftmarketplace

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class NftmarketplaceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
